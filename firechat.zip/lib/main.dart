import 'package:chat_app/data/local/shared_prefs.dart';
import 'package:chat_app/data/remote/firebase/firebase_client.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'presentation/splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  FirebaseClient.initSDK();
  SharedPrefs.init();
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
    );
  }
}