class AppConfig {
  static const areLogsEnabled = true;
}