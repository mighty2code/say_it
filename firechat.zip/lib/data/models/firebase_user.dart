class FirebaseUser {
  String? name;
  String? username;
  String? email;
  String? password;

  FirebaseUser({
    this.name,
    this.username,
    this.email,
    this.password,
  });

  factory FirebaseUser.fromJson(Map<String, dynamic> json) {
    return FirebaseUser(
      name: json['name']?.toString() ?? '',
      username: json['username']?.toString() ?? '',
      email: json['email']?.toString() ?? '',
      password: json['password']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'username': username,
      'email': email,
      // 'password': password,
    };
  }
}
