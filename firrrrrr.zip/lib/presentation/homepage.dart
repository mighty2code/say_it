
import 'dart:convert';

import 'package:chat_app/constants/app_colors.dart';
import 'package:chat_app/constants/constants.dart';
import 'package:chat_app/data/local/shared_prefs.dart';
import 'package:chat_app/data/models/firebase_user.dart';
import 'package:chat_app/data/remote/firebase/firebase_client.dart';
import 'package:chat_app/presentation/auth/login_screen.dart';
import 'package:chat_app/presentation/chat_page.dart';
import 'package:chat_app/utils/dialog_utils.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({
    super.key,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  List<FirebaseUser> users = [];

  @override
  void initState() {
    final savedUsers = SharedPrefs.getStringList(SharedPrefsKeys.users) ?? [];
    for (var user in savedUsers) {
      users.add(FirebaseUser.fromRawJson(user));
    }
    setState(() {});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(AppConfig.name, style: TextStyle(color: Colors.white)),
            Text(SharedPrefs.getString(SharedPrefsKeys.name) ?? '', style: const TextStyle(fontSize: 14, color: Colors.white)),
          ],
        ),
        backgroundColor: AppColors.appColor,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: InkWell(
              onTap:() {
                FirebaseClient.signOut();
                Navigator.of(context).pushReplacement(MaterialPageRoute(builder:(context) => LoginScreen()));
              },
              child: const Icon(Icons.logout, color: Colors.white)
            ),
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.max,
        children: [
          Flexible(
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 10),
              itemCount: users.length,
              itemBuilder: (_, index) {
                return InkWell(
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(builder:(context) => ChatPage(receiverId: users[index].id ?? '')));
                  },
                  child: Card(
                    child: ListTile(
                      leading: const Icon(Icons.person, color: AppColors.appColor),
                      title: Text(users[index].name ?? ''),
                    ),
                  )
                );
              },
              separatorBuilder: (BuildContext context, int index) => const SizedBox(height: 8), 
            ),
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // DialogUtils.showInputBox(
          //   context,
          //   title: 'Add User',
          //   hintText: 'Enter username',
          //   buttonText: 'Add',
          //   onSubmit: (value) async {
          //     users.add(value);
          //     await SharedPrefs.setStringList(SharedPrefsKeys.users, users);
          //     setState(() {});
          //   }
          // );
        },
        backgroundColor: AppColors.appColor.shade100,
        child: const Icon(Icons.add, color: AppColors.appColor),
      ),
    );
  }
}