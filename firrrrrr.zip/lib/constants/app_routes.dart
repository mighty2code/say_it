class AppRoutes {
  static const splash = '/splash';
  static const login = '/login';
  static const signUp = '/signUp';
  static const homePage = '/homePage';
  static const chat = '/chat';
}